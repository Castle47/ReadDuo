---
name: readduo-setup
description: Check the local ReadDuo native candidate on an Apple-silicon Mac and identify missing Poppler or system fonts.
---

# Set up ReadDuo

Read the sibling readduo skill's references/native-cli.md. Run its
scripts/bilingual_pdf runtime-check from that skill folder. The Python runtime
and Python dependencies are bundled. Do not install the development source or
change system Python. Report missing Poppler or macOS fonts. This candidate is
for the publisher's local evaluation and is not cleared for public distribution.
Do not start a translation unless asked.
