# Independent translation and layout QA

## Contents

1. Reviewer isolation
2. Review passes
3. Finding format
4. Findings and authorized follow-up
5. Acceptance criteria
6. Re-review

## 1. Reviewer isolation

Use a subagent or fresh agent that did not create the draft. Provide raw artifacts and minimal context:

A mechanically certified PDF or a draft with findings can be reviewed. For a
draft, diagnose its limitations without treating review as mechanical
certification. The durable job API reports requested review as pending.

- source PDF;
- translated or bilingual PDF;
- page decision manifest;
- glossary;
- mechanical audit report.

Also provide the recorded figure/chart text policy and per-figure decisions.
Do not flag embedded text as untranslated when it was intentionally preserved
under a user override or a documented `auto` decision. Do flag violations of
the chosen policy and weak `auto` decisions whose rationale conflicts with the
rendered evidence.

Do not provide the creator's conclusions, suspected defects, or expected verdict.

Suggested reviewer prompt:

> Review this source PDF and translated PDF independently. Check every page for translation completeness and accuracy, terminology consistency, numeric and citation fidelity, reading order, and visual layout. Inspect tables, figures, rotated content, formulas, headings, footnotes, and mixed-language text. Report only evidence-backed findings with page number, region, severity, category, source excerpt, observed target, and a concrete fix. Also state which pages were visually inspected at full resolution.

## 2. Review passes

Perform separate passes:

1. **Coverage:** map every semantic source region to translated, intentionally preserved, or approved omitted content.
2. **Accuracy:** compare meaning, qualifiers, terminology, numbers, units, variables, references, and names.
3. **Layout:** inspect rendered pages for overflow, overlap, clipping, cross-column intrusion, bad wrapping, unreadable type, style mismatch, and misplaced captions.
4. **Structured content:** inspect each table, chart, formula, list, footnote, and rotated region.
5. **Protected spans:** compare spelling, case, glyphs, punctuation, and line breaking for model names, personal names, formulas, URLs, citations, and appendix references.
6. **Consistency:** compare repeated headings, terms, abbreviations, punctuation, fonts, and spacing across pages.
7. **Navigation:** open the outline, test representative entries at every
   hierarchy level, click external links, and test internal links on both source
   and translation panels. Confirm that each destination lands in the intended
   panel and section.

For figures and charts, verify policy compliance before coverage:

- `preserve`: artwork and embedded labels remain unchanged and readable;
- `translate`: meaningful embedded text is translated without damaging
  geometry or quantitative evidence;
- `auto`: sparse-text preservation or dense-text translation is supported by
  the recorded visual and semantic rationale.

Use full-resolution page images for suspected issues. Contact sheets are for triage only.
For suspected missing glyphs in a clipped render, render the complete page and
crop that image before filing a PDF defect. A PDF renderer's direct clip path
can omit glyphs even when full-page rendering is intact. If those views
disagree, compare a second renderer and record the rendering limitation.

## 3. Finding format

Return findings in a stable structure:

```json
{
  "id": "QA-P001-01",
  "page": 4,
  "region": [54, 620, 296, 717],
  "severity": "major",
  "category": "layout-overflow",
  "source": "Meanwhile, by combining...",
  "observed": "The paragraph was treated as a heading and crosses the gutter.",
  "fix": "Classify as body text, render regular weight, and wrap to the column width."
}
```

Assign IDs after reviewer isolation is complete so the creator cannot bias the
review. Keep IDs stable across approval, fixes, and re-review.

Severity:

- `critical`: missing page/section, corrupted meaning, unreadable output, or material numeric/formula error;
- `major`: omitted paragraph, mistranslation, broken table, overlap, clipping, or cross-column intrusion;
- `minor`: local terminology, spacing, punctuation, or small visual inconsistency;
- `suggestion`: optional improvement with no correctness impact.

## 4. Findings and authorized follow-up

Deduplicate the reviewer's findings and mechanical findings, and preserve stable
IDs in a separate review record. Review does not mutate a frozen translation
job. A request for review alone produces findings. If the user has already
authorized fixes, including the skill's default post-layout repair during
translation, follow [post-layout-repair.md](post-layout-repair.md) for bounded
PDF repairs. General engine changes use the development context, a regression
case and replay through the public API. Ask about
an unresolved product or translation choice only when existing authorization
does not settle it; do not require another approval for already requested fixes.

Each checklist item must include:

- stable finding ID;
- source page and region;
- severity and category;
- concise evidence;
- proposed change;
- expected visual or semantic impact.

Persist the response:

```json
{
  "finding_id": "QA-P001-01",
  "decision": "approved",
  "user_note": "Restore the formula but keep the surrounding English term."
}
```

Allowed decisions are `approved`, `rejected`, and `deferred`. Record the existing
user authorization for approved implementation work. Do not infer authorization
from silence or interpret it as a passed quality check.

If the independent review contains no actionable findings, store an empty
decision list and continue without asking the user to approve an empty checklist.

## 5. Acceptance criteria

Accept only when:

- all selected pages and semantic regions are accounted for;
- every approved critical or major finding is resolved;
- all tables retain cell structure and correct values;
- formulas, references, names, numbers, and units are intact;
- no text overlaps, clips, crosses gutters, or falls outside its region;
- heading hierarchy and body weight match the source;
- translated prose has natural line wrapping and readable line spacing;
- intentional preservation decisions are documented.
- outline entries and retained hyperlinks open the correct destinations; every
  selected-page omission is explicitly documented.

Rejected or deferred critical/major findings prevent an unqualified “QA
passed” verdict. They may remain only when the user explicitly chooses to
proceed, and must be listed as known issues.

## 6. Re-review

After approved fixes, give the reviewer the revised PDF and the approved prior
finding IDs. Ask it to verify each fix and perform a regression scan of affected
pages. Record new findings and apply the same scope rules. Do not accept “fixed by
inspection” from the creator as the final gate.
