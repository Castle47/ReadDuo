# ReadDuo native desktop commands

This local candidate contains a compiled macOS arm64 engine. Python source,
tests and compiler files are not part of the plugin. The skill instructions
and command protocols remain readable. The candidate is for local evaluation;
PyMuPDF commercial distribution permission has not been verified.

## Setup and files

Run `scripts/bilingual_pdf runtime-check` from the ReadDuo skill folder. The
engine bundles its Python runtime and Python dependencies. It still needs
Poppler (`pdftoppm` on PATH) and the macOS Songti SC / Times New Roman fonts.
It is built for Apple silicon and has not been tested on Intel Macs.

Store PDFs, jobs, translations and outputs outside the installed plugin.
Resolve all relative commands from this skill's directory. Do not set
PYTHONPATH, install a different engine, or attempt to import private modules.

## Translation

The normal job commands and JSON protocols are available unchanged:

```sh
scripts/bilingual_pdf create source.pdf --job-dir /absolute/path/to/job \
  --source-language en --target-language zh-CN
scripts/bilingual_pdf prepare-context --job-dir /absolute/path/to/job \
  --output /absolute/path/to/client/context.json
scripts/bilingual_pdf next-work --job-dir /absolute/path/to/job \
  --workers 1 --output-dir /absolute/path/to/client
scripts/bilingual_pdf collect-work --job-dir /absolute/path/to/job \
  --input /absolute/path/to/client/GROUP.response.json
scripts/bilingual_pdf finalize --job-dir /absolute/path/to/job
scripts/bilingual_pdf resume --job-dir /absolute/path/to/job
```

The active host model generates translations. The engine does not call a
separate translation service. Host model/file handling still applies.

## Render the actual output

```sh
scripts/bilingual_pdf render /absolute/path/to/translated.pdf \
  /absolute/path/to/review --dpi 150
```

Inspect every requested page at readable size. Keep findings and review status
in the sibling `.issues.md`, not on the PDF pages. For later localized repairs,
rerender the modified pages and preserve healthy pages.

## Bounded native repairs

Use `scripts/bilingual_pdf repair text --input repair.json` to call the shared
measured text repair. The JSON object contains `source_path`, `input_path`,
`output_path`, `page_number`, `clear_box`, `text`, `font_manifest`, `font_size`
and `leading`. Optional fields include `text_box`, `alignment`, `bold`,
`formula_assets` and `list_item`. Paths are absolute, page numbers are 1-based,
and boxes use source-page coordinates.

Use `scripts/bilingual_pdf repair region --input repair.json` for native
artwork restoration. Its JSON contains `source_path`, `input_path`,
`output_path`, `page_number`, `clear_box` and `source_box`, plus optional
`verification_policy` (`readable` or `strict`). Preserve full source objects,
including detached accents. Do not pass Python paragraph-plan objects through
this interface; use the text repair command when prose also needs repair.

Each repair writes a separate PDF and returns JSON diagnostics. It does not
certify visual quality. Keep the original mechanical PDF, render the candidate,
check the actual repaired region and nearby text, and update the issue list.
Do not edit frozen job state or certification flags to claim a repair passed.

## Diagnostic worker tools

`scripts/bilingual_pdf --readduo-stage TOOL --help` exposes the bundled tools
for inspection, page modeling, fonts, preflight and audit. Tool names are
allowlisted; arbitrary Python code execution and Python SDK imports are not
provided by this distribution.

The mechanical source/formula audit runs during the private build. At runtime
the engine requires its build evidence and checks typography policy, catalog
provenance, input hashes and output diagnostics. It does not pretend to parse
source files that are absent from this compiled package.
