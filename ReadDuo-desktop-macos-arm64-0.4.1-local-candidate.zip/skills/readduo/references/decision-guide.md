# Translation and layout decision guide

Candidate availability takes precedence over quality-related stop/fail
instructions below. Keep the translated PDF candidate and source evidence,
record all findings, and let visual inspection decide what is visibly wrong.
Unsafe geometry or markers never justify replacing saved targets with an English
source page. Region-level recovery continues drawing other targets; a source-only
page is valid only when no target text is available; describe it in the checklist,
without adding a warning or system status footer to the PDF. Healthy pages keep normal
geometry. Strict checks affect acceptance; they do not erase a generated
candidate. Identity, provenance and file I/O errors remain operational limits.
Follow mechanical generation with the default
[intelligent repair pass](post-layout-repair.md).

## Contents

1. Evidence hierarchy
2. Region classification
3. Translate or preserve
4. Images and charts
5. Tables
6. Layout adaptation
7. Failure patterns

## 1. Evidence hierarchy

Use this evidence when developing deterministic extraction/layout rules:

1. rendered page at readable resolution;
2. PDF geometry, fonts, drawing objects, and image bounds;
3. extracted text and reading order;
4. current-model target text for exact extracted templates, or a human-supplied
   text map when source text is not otherwise extractable.

The production runner itself branches only on recorded geometry and fixed
thresholds. It never sends a render to a model and never invokes OCR or a
network service. Before the runner starts, the active host model translates
only the extracted catalog templates. After the runner returns, it may inspect
source pages and diagnostics and repair abnormal output pages in separate
candidates. If extraction cannot supply a stable source region, record it for
that pass; the engine still requires an OCR source for scanned or damaged text.

For host-model catalogs, all extraction, classification, pilot selection,
layout, audit, and preflight occur inside one closed mechanical session. Do not
show those intermediate artifacts to the translating model. Once mechanical
execution starts, do not shorten wording, restore markers, alter paragraph
boundaries or rebuild the frozen page model. The outer durable job may resume
or replay frozen inputs within its recorded attempt budget. Deterministic layout findings are
recorded and the resulting PDF becomes the mechanical draft for post-layout
repair. The closed scope does not extend to that subsequent repair pass.

## 2. Region classification

Classify each meaningful region before editing:

| Role | Typical action | Key constraint |
|---|---|---|
| Title or heading | Translate | Preserve hierarchy and numbering |
| Body paragraph | Translate and reflow | Do not preserve hard line breaks |
| Logical paragraph boundary inside one PDF block | Preserve as a paragraph boundary and source-derived paragraph gap | Do not flatten it into ordinary leading |
| Compact centred title/front matter rows | Translate as a semantic row group on one common visual axis | Do not align each row to its extracted bbox |
| Author/byline metadata between title and first prose section | Preserve as one source-owned band | Do not independently reflow names, affiliations, or emails |
| Bottom text | Fix only repeated running matter; reflow page-local footnotes | Do not classify from y-position alone |
| Inline formula component group | Restore as one opaque vector unit | Move all original components together |
| Caption or footnote | Translate | Keep attachment to figure/table |
| Table body | Preserve cells, data and rules | Translate the separate table title/caption |
| Pseudocode algorithm | Preserve complete source block | Preserve its caption and internal text |
| Chart | Overlay or redraw labels | Preserve data geometry |
| Formula | Preserve as source-derived object | Standalone stays fixed; inline moves intact with prose |
| Math-dominant display row fragmented across text blocks | Preserve every same-column row component at source geometry | Never absorb a URL, heading, long prose block, or opposite-column region |
| Code or identifier | Preserve | Avoid typography substitutions |
| Proper name | Usually preserve | Follow requested localization |
| URL/email/citation key | Preserve | Keep byte-for-byte where possible |
| Bibliography section | Preserve | Keep heading and every entry source-identical through the next top-level section |
| Decorative image/logo | Preserve | Do not OCR decorative marks |
| Scanned prose | Report needs-ocr and require an OCR source | Catalog translation cannot substitute for source extraction |

Before relying on catalog completion, inspect the preparation's independent
source-coverage report. A native block can be extracted successfully yet be
misclassified as a preserved identifier or table cell. Normal prose and caption
continuations override accidental chart ownership; compact genuine figure labels,
table cells, pseudocode and bibliography remain protected. Broad, mostly
off-page drawing bounds alone cannot establish figure ownership of a formula.

Treat mixed regions as composites. A figure can contain a preserved diagram, translated labels, and a translated caption.
Figure-caption prefixes belong to the caption layer even when their boxes
touch the preserved artwork. A rule-bounded, multi-line document title owns
every matching title row before the author metadata band.

On a stable two-column page, determine bibliography state in column reading
order (left column top-to-bottom, then right column top-to-bottom), not by a
global y-coordinate sort. This is required when a `REFERENCES` heading appears
near the bottom of the left column and later entries continue at the top of the
right column.
Treat a standalone `APPENDIX` or `APPENDICES` heading as an explicit end of the
bibliography state, including when a prior pass temporarily labelled that
heading as bibliography content.
Unnumbered technical-appendix and supplementary-material headings also end
that state; their presence must be assessed before preserving the next region.

## 3. Translate or preserve

### Translate

- prose needed to understand the document;
- section headings, labels, legends, callouts, and instructions;
- meaningful text embedded in screenshots when legible and relevant;
- accessibility text that is visible in the source.

### Preserve

- mathematical expressions, variable names, dataset identifiers, model names, and code;
- table bodies and complete pseudocode algorithms; table captions are translated;
- URLs, emails, DOIs, reference keys, file paths, and command examples;
- names and affiliations unless the target convention or user requests localization;
- numbers and units, changing only typographic spacing required by the locale;
- logos, signatures, stamps, and decorative marks.

### Catalog-side translation decisions

- During catalog translation, the active host model fills only catalog `text`
  fields; geometry and layout decisions belong to the engine until it returns.
- Apply only decisions already encoded in the completed catalog and glossary.
- Preserve product/model names and protected identifiers declared by the page model.
- If the completed catalog has no entry for a required region, record the
  coverage defect; the mechanical script must not invent text. The subsequent
  repair pass may transcribe and translate the verified source region with
  provenance, without editing the frozen catalog.
- If scanned or embedded source text cannot be extracted deterministically,
  preserve the source object and report the missing human input.

## 4. Images and charts

Resolve the document-level or region-level policy first:

- `preserve`: keep figure/chart artwork and embedded text unchanged. Translate
  the caption unless the user also excludes captions. Do not OCR or overlay the
  figure merely to satisfy target-language coverage.
- `translate`: translate meaningful labels, legends, callouts, prose blocks,
  workflow steps, and instructions; preserve data values, formulas, model names,
  and geometry.
- `auto` (default): classify compound graphics with fixed thresholds and record
  the inputs in the page model. Preserve sparse compounds as one source-owned
  layer. For dense compounds with an extractable native text layer, translate
  meaningful labels while preserving data geometry and protected identifiers.

When `auto` preserves a sparse compound graphic, keep its internal labels with
the same source object. Do not reflow short legends, axis labels, or identifiers
as independent paragraphs merely because the PDF exposes them as text blocks.

In `auto`, classify a detected compound graphic as `sparse` only when all
three conditions hold: at most 20 internal regions, at most 300 extracted
characters, and internal text boxes covering at most 18% of the compound area.
Record the counts, area ratio, thresholds, source box, and action. Sparse means
`action=preserve`; dense means `action=translate` only when source labels are
individually extractable and removable. Density is never permission to create
a second label layer. If a dense raster figure has no separable text layer,
preserve it and require a human-supplied text map or a documented companion
translation rather than OCR or destructive overlay.

Every figure has exactly one text-layer owner. `preserve` and sparse `auto`
decisions keep the source layer and forbid target overlays. Explicit
`translate` and dense `auto` decisions assign ownership to the target layer:
remove all source-owned label glyphs before drawing any target labels, then
mechanically prove that no source label remains. If the PDF does not permit
clean source-label isolation, record the ownership defect and retain a visibly flagged translated candidate
for visual review instead of suppressing the page.

Choose the least destructive readable method:

1. preserve the image and translate only its caption;
2. overlay translated labels while retaining the original graphic;
3. redraw the chart or diagram when labels cannot be overlaid cleanly;
4. place a translated companion figure when altering the source would obscure evidence.

Keep data points, axes, units, legends, colors, arrows, and references unchanged. Do not use generative image editing for charts containing quantitative evidence unless the source data is reconstructed and verified.

Interpret “图表不翻译” or equivalent as preserving figures, charts, diagrams,
tables, pseudocode algorithms, their captions, and all embedded text. Honor
explicit exceptions such as “Figure 2 only.”

## 5. Tables and pseudocode algorithms

Treat each table body as a source-owned object. Preserve its headers, cells,
values, rules, internal formulas and notes. Keep the linguistic title/caption
outside that envelope and include it in the translation catalog. Preserve
pseudocode algorithms, including their captions, as complete source objects.

## 6. Layout adaptation

For bilingual side-by-side output:

- use equal source and translation panels by default;
- preserve the source panel exactly when possible;
- allow the translated panel to reflow internally while keeping the same page correspondence;
- maintain a real gutter between panels and between internal columns;
- constrain all drawing to the assigned panel and column rectangles.

For selected page ranges:

- treat page numbers as 1-based source PDF pages;
- translate only selected pages;
- retain original source page numbers in manifests and review findings;
- for selected-only output, map selected source pages sequentially to output
  pages and record that mapping;
- for full-document output, leave unselected pages unchanged and exclude them
  from untranslated-content findings.

Typography:

- body text stays regular unless the source is emphasized;
- stacked numbered headings that share one extraction block remain separate
  hierarchy rows; a top-level heading and its subsection are never translated
  as one line;
- source bullet starts define paragraph boundaries even when PDF extraction
  flattened the list into one block;
- headings match the source's relative weight and size;
- multi-line semantic titles and headings retain at least the source line count,
  with balanced target-language wrapping rather than copied hard returns;
- preserve one visible space after hierarchical section numbers;
- use target-language-appropriate line spacing;
- preserve source formula-expanded gaps once; use a bounded optical CJK floor
  only for ordinary tight lines instead of multiplying every local source gap;
- leave every paragraph-final line ragged; two-sided justification applies only
  to eligible nonfinal lines;
- avoid copied hard returns and accidental ragged short lines;
- permit Latin token breaks only to prevent overflow, not as the first choice for ordinary prose.

## 7. Failure patterns

Layout failures are diagnostic evidence, never output vetoes. Draw the full
available target prose as a source-anchored review candidate even when it may
overlap, clip or contain unresolved math. Record each failure and visually inspect
the actual translated page before deciding on a repair. A failed region must not
discard neighbouring targets. Emergency rendering may visibly degrade only the
affected page; preserved scientific evidence remains on the source panel. Only
pages with no available target text may remain source-only, marked incomplete.
Do not call an unresolved review candidate clean or complete.

Actively look for:

- a localized bold term causing an entire paragraph to be classified as a heading;
- text writers that measure a line but never wrap it;
- mixed-script cleanup deleting the space after a section number;
- translated tables flattened into prose or redrawn without cell constraints;
- clipping hidden because PDF insertion silently failed;
- text crossing a column gutter;
- translation fitted only by shrinking body text below a readable size;
- protected model names split across lines merely because ordinary word breaking is enabled;
- formula glyphs such as `g`, `α`, subscripts, or superscripts dropped because the PDF extractor emitted them in separate font spans;
- author names, appendix references, or citation identifiers changed by translation or target-language punctuation;
- formulas or citations translated as prose;
- bibliography headings or entries translated, normalized, or re-punctuated;
- ordinary prose with several citations and URL mentions misclassified as a
  bibliography block despite not beginning with a reference-entry marker;
- source figure labels and translated labels painted at the same coordinates;
- Latin/digit runs in translated prose rendered by the CJK font instead of
  Times New Roman;
- page headers, footers, or side labels omitted because of orientation;
- a zero-height footer rule excluded from collision checks, allowing body text
  to enter the fixed footnote zone;
- fixed header text whose baseline was recomputed from the target glyph box and
  therefore sits too close to the rule;
- formula control glyphs or delimiter fragments selected as the line baseline,
  producing inflated or erratic target leading;
- formula-bearing adjacent lines whose visible ink envelopes overlap because a
  global leading cap overrode collision clearance;
- a right-margin numbered display row sharing an extraction block with the
  following prose; resolve glyph ownership before merging paragraph regions;
- a short source prefix left beneath translated text because an inline-region
  merge discarded its plain-span ownership;
- clipped-text membership changing at a rounded boundary after PDF Form
  placement; compare stable glyph origins/geometry with bounded coordinate
  tolerance instead of exact clipped strings;
- a rectangular formula clip carrying the bottom strokes of neighbouring prose
  from the preceding source line;
- neutral formula digits or interval brackets disappearing because their roman
  font was conservatively classified as prose;
- equivalent closing punctuation drawn once by the formula object and again by
  the translated prose, producing a screenshot-like double delimiter;
- a plain variable base stranded at line end while its protected subscript or
  superscript begins the next line;
- formulas copied from review renders or raster crops instead of native PDF
  vector objects;
- declared paragraph breaks whose numeric gap survives but disappears
  optically in CJK text;
- scanned pages falsely treated as blank;
- repeated content translated inconsistently.
- shortening meaning after reading capacity or preflight output merely to fit;
- mutating frozen inputs or mechanical reports to disguise a post-layout repair
  as a certified engine output;
