# Translation style and terminology

## Contents

1. Source fidelity
2. Structural fidelity
3. Terminology
4. Mixed-script typography
5. Tables, formulas, and citations

## 1. Source fidelity

Accept only catalog text supported by the document. The active host model may
generate target prose from exact extracted templates before production starts;
the production scripts themselves do not generate prose or consult model
memory. Preserve uncertainty, scope, negation, modality, and comparison
direction in every catalog regardless of its origin.

Generate each translation from source meaning only. Do not inspect slot width,
line count, overflow, pilot renders, audit, or preflight, and do not shorten or
rewrite target text in response to layout capacity. Each accepted batch is saved by the job API. Finalization freezes the completed
translation for mechanical execution and any requested replay.

Check every:

- number, percentage, date, unit, range, and sign;
- model, dataset, organization, and product name;
- equation number, figure number, table number, and citation;
- footnote marker and cross-reference.

Prefer natural target-language syntax over literal source word order, but do not summarize unless requested.

## 2. Structural fidelity

Maintain source granularity:

- heading to heading;
- paragraph to paragraph;
- list item to list item;
- caption to caption;
- table cell to corresponding table cell.

Numbered items such as `(1)` and `(2)` are distinct semantic units, even when
PDF extraction joins the second marker to the first item or splits one item
around a fraction. Preserve each issued item's marker and full content. Keep a
bold source label such as `Smoothness` or `Early/Late Spend` as a label followed
by a colon in the target; the renderer maps its bold style separately from the
regular number and body. Do not add spaces to simulate hanging indentation or
manually shorten the body to fit. The renderer owns the marker/body columns.

Do not merge unrelated paragraphs to make layout easier. Do not split a logical sentence merely because the source PDF contains a line break.
When one extracted PDF block contains multiple source paragraphs, preserve them
as blank-line-separated target paragraphs. Semantic title or front-matter rows
are different: preserve their row count and row meaning, but do not treat them
as prose paragraphs.
For every declared prose paragraph boundary, retain the scaled source excess
baseline gap and enforce a deterministic minimum visible separation of
`0.35 em`; do not create larger gaps between ordinary wrapped lines.

## 3. Terminology

Prepare a document-specific shared glossary before translation. The host model
reviews candidates from the full requested catalog and surrounding context,
identifies technical terminology, model/dataset names and abbreviations, and
sets consistent target forms; candidates do not themselves prove a term's meaning.
Pass the source-to-target mapping to every group and retain it outside the
engine-managed job files. For an existing frozen job preserve its recorded glossary.
For example, a richer client-side terminology note can be:

```json
{
  "source": "ranking model",
  "target": "排序模型",
  "status": "approved",
  "preserve_case": false,
  "notes": "Use consistently in prose and table headers"
}
```

Protect model names, personal names, acronyms, identifiers, cross-references,
and formulas in catalog entries. Preserve paired `<LINK:id>...</LINK:id>`
markers around linked target text; the markers are structural and invisible,
while their contents may be translated unless independently protected. Treat
each protected string as an atomic no-break span during layout. The compiler records marker defects in advisory mode and keeps target prose
available for review rendering. Strict text acceptance may require correction;
a generated PDF candidate must still be retained for visual checking.

When no stable translation exists:

1. preserve the source term;
2. optionally add a concise target-language explanation on first use;
3. use the same form thereafter.

## 4. Mixed-script typography

- Segment translated text into Unicode script runs before measurement and
  rendering. Use Songti SC for CJK runs and Times New Roman for every Latin
  letter and digit run, including English model names embedded in Chinese
  prose. Protected formulas, code, logos, and preserved figures retain their
  source fonts.
- Use target-language punctuation in translated prose, except inside code, formulas, URLs, and exact identifiers.
- Punctuation between MATH markers may belong inside a mathematical function
  argument. Preserve such separators exactly (for example ASCII `;`), even
  when extraction split the expression into several markers.
- Preserve a visible space between a section number and title: `3.4 相关工作`, not `3.4相关工作`.
- Avoid inserting arbitrary spaces between every CJK character and Latin token.
- Keep units and symbols attached according to the target locale and scientific convention.
- Let the layout engine choose line breaks from measured widths.
- Break ordinary long Latin strings at controlled character boundaries when they would otherwise overflow.
- Never break protected model names, variables, URLs, citations, appendix references, or personal names. Reflow the region or adjust local typography instead.
- Use a regular body font. Apply bold only to source-emphasized text or semantic headings. Preserve mixed source weight as inline runs; a bold prefix must not make the following regular sentence bold.

## 5. Tables, formulas, and citations

Translate table titles and captions as prose. Preserve table bodies and pseudocode
source-identically, including headers, cells, rules, values, footnotes, line numbers,
keywords and internal formulas. If the engine omits a table caption from the
catalog, extract and translate it from the source, then render it above the intact
table and visually check it.

Standalone formula paragraphs remain unchanged at source geometry. Replace each
inline formula with a typed placeholder during translation, then restore the
same source-derived formula as one indivisible vector unit during typesetting.
The unit may move with surrounding translated text, but its glyphs, scripts,
curves, forms, spacing, size, and internal relative geometry must not change.

Preserve the visible source color of linked citations and cross-references in
the translated text. Link annotations and link typography are separate
requirements; a clickable black target reference is not equivalent to a blue
source reference.

Compare formulas and inline variables at glyph level, because PDF extraction commonly separates math spans from surrounding prose. Confirm that symbols such as `g(·)`, `α`, subscripts, and equation references remain intact inside the relocated opaque unit.

Treat every source glyph inside an established formula's semantic envelope and on one of its declared formula baselines as formula content, even when a roman font makes an upright operator, interval digit, or delimiter resemble prose. Edge position and a font change are not grounds for omission. At a formula boundary, render equivalent source/target closing punctuation only once; do not alter the completed catalog or retype the formula.

Never translate a bibliography section. Preserve the References/Bibliography
heading and every entry source-identically through the next top-level section,
including titles, authors, venue text, dates, punctuation, DOI/URL strings, and
linked citation text. This is a permanent production rule, not a per-document
preference and not an excuse to preserve ordinary prose elsewhere.
