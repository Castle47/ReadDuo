# Durable translation jobs — API v1

The `bilingual_pdf` Python package contains the complete processing engine. It
does not read SKILL.md, require a chat session, or call a model service. The skill
is one client of the same interface used by terminals and Python applications.

## Installation and entry points

This candidate uses the native `scripts/bilingual_pdf` launcher. See [native-cli.md](native-cli.md). Python imports and the Python SDK are not available.

## Commands

```sh
scripts/bilingual_pdf create source.pdf --job-dir work/paper \
  --source-language en --target-language zh-CN \
  --translation-generator active-host-model
scripts/bilingual_pdf next-batch --job-dir work/paper --output work/batch.json
scripts/bilingual_pdf submit --job-dir work/paper --input work/submission.json
scripts/bilingual_pdf revise --job-dir work/paper --input work/revision.json
scripts/bilingual_pdf status --job-dir work/paper
scripts/bilingual_pdf finalize --job-dir work/paper
scripts/bilingual_pdf resume --job-dir work/paper
scripts/bilingual_pdf replay --job-dir work/paper
```

Omitting `--pages` selects the complete source. Defaults are bilingual output,
automatic figure policy, no independent QA, and at most three mechanical
attempts. New jobs use `--validation-policy advisory` by default. Quality checks record findings without suppressing the translated candidate.
`strict` retains strict text acceptance and fidelity checks; a generated
candidate remains available even when its quality checks fail. `--output` may name a file outside the managed job directory; otherwise
the result is `<job-dir>/translated.pdf`. Batch and submission files belong
outside the managed job directory.

For advisory jobs, preflight uses the readable quality profile: missing text,
formula damage, visible collisions, clipping and substantial graphics loss remain
critical. Font-family, small fixed-position and modest graphics-rendering
differences are recorded as warnings and do not force an untranslated fallback.
Strict jobs retain exact presentation checks. Fully off-page vector paths are
excluded from new inventories and ignored when checking older frozen manifests;
partly visible paths and edge-touching strokes remain protected.

Bilingual composition preserves source scale and y coordinates while compacting
facing margins to half their original combined whitespace. The manifest records
`bilingual_layout` (clips, divider, translation offset, original/compact gap).
Internal links, outlines and audit use this offset instead of assuming a full
source-page width. Source header rules, numbered-heading baselines, normal source
leading and native display-equation position are mechanical requirements even
for advisory jobs.

Every delivered PDF has a UTF-8 Markdown checklist beside it, for example
`translated.pdf` and `translated.issues.md`. `result.issues_markdown` returns its
path. The list contains source page/entry IDs, translation warnings, extraction
fallbacks, missing text and layout findings. No findings still produces a list.
Ordinary `resume` preserves edits the user has made to it.

Older jobs without a policy retain strict behavior until explicitly changed:

```sh
scripts/bilingual_pdf validation-policy --job-dir work/paper --policy advisory
```

This changes delivery policy without rewriting frozen inputs or accepted text.
Recollect previously rejected responses. Source hashes, foreign IDs, conflicting
receipts and malformed envelopes remain operational/protocol checks.

`--translation-origin model|human|translation-memory` records the source of the
submitted text; the default is model. `--translation-generator` identifies the
specific client. All durable jobs use a `client-catalog` with the same frozen
session guards. Human and memory submissions correctly declare no model
assistance. Legacy `host-model` catalogs remain compatible.

Newly prepared jobs publish `source_coverage` in status, with suspected source
block count, page numbers and a durable `source-coverage.json` report. It compares
the native PDF's prose/caption/title/heading blocks with nearby translating
regions after preservation rules run. False positives (for example prose inside a
deliberately preserved table) must be checked against the source. Unresolved
warnings remain in the delivery checklist and keep `translation_complete` false;
they do not suppress translated candidates. Coverage checks do not prove
completeness, do not perform OCR and do not automatically translate an ambiguous
source-owned block. A check failure is reported per page without stopping other
pages. Prior frozen jobs retain their original models and do not acquire this
check retroactively.

`next-batch` persists one outstanding batch. Repeated calls, even from a new
process or after a moved job directory, return the same ID and entries until
accepted. Size is 1–60 entries. After the last submission it returns `batch: null`
and `next_action: finalize`. It does not choose a model or generate target text.
`--max-source-chars N` additionally limits the source-template length of a new
batch. A single longer entry is kept whole. Existing outstanding batches never
change when new size options are supplied.

## Parallel translation groups (0.3.0)

```sh
scripts/bilingual_pdf next-work --job-dir work/paper --workers 3 \
  --max-source-chars 4000 --glossary glossary.json --output-dir work/paper-client
scripts/bilingual_pdf collect-work --job-dir work/paper \
  --input work/paper-client/GROUP.response.json --output-dir work/paper-client
```

The API accepts an optional glossary mapping source strings to target strings. The
translator skill requires the host to prepare a paper-specific glossary before
starting a new translation. It is frozen
on first dispatch, shared across all groups, and reused when the option is omitted.
A different glossary is rejected. Each worker gets source entries, paragraph
counts, the glossary and at most 1,200 characters of source context on either
side. Context is labelled and is not an output entry. No coordinates, fonts,
source hashes or duplicated line text are sent to the worker.

`next-work` balances consecutive whole entries by source-template character
count, including typed markers. `max-source-chars` is a per-group budget, not a
token limit. Single oversized entries remain intact and are reported through
`oversized_entries`; never truncate or summarize them. Tiny adjacent groups may
be combined within the budget to avoid a separate model call for a heading.
An old outstanding batch can yield more groups than workers. Limit simultaneous
calls to the requested 1–3 workers; queue the remaining groups.

With `--output-dir`, the result lists each request path and response path instead
of repeating its source text. Without it, full task packets are returned as JSON.
Each response has exactly these fields:

```json
{
  "api_version": 1,
  "batch_id": "issued-batch-id",
  "group_id": "issued-group-id",
  "translations": {"issued-entry-id": "Target text"}
}
```

`submit-group --input response.json` validates and stages one complete group.
`collect-work --input response1.json response2.json ...` checks all supplied
files, saves valid siblings even if another fails, and returns the next pending
tasks. Failed files are reported in `errors` and give exit code 2. No failure is
silently skipped. Do not launch a second worker for an ID already in flight.

The last valid group commits the whole batch atomically in source order.
Before that, `staged_entries` and `pending_groups` expose partial progress;
`translated_entries` counts committed batches only. Strict finalization requires
all entries. Advisory finalization can deliver available text and list each
missing entry when the client cannot continue. Group receipts make identical
resubmissions safe across processes and relocation. Conflicting receipts and
foreign IDs remain rejected. Marker, paragraph and content findings are saved
in advisory mode; unsafe structure is drawn as a flagged review candidate,
with page-local plain-prose recovery when rich markers cannot be rendered. A legacy whole-batch submit
may finish grouped work only if it agrees with every already saved group.

Use `next-work` to resume grouped work; it reissues only unsaved groups. A response
file that was written before interruption can be collected without regenerating
its text. Worker failures do not consume the separate mechanical attempt budget.

The engine does not start a model. The skill delegates bounded text-only work
when its host supports it. A Python client can provide a thread-safe callback:

```python
result = job.translate_parallel_with(
    translate, workers=3, max_source_chars=4000,
    glossary={"attention": "注意力"}, max_retries=1,
)
```

This callback receives a group packet and returns only the ID→text mapping.
The adapter runs callbacks concurrently, saves valid results, retries only failed
groups, and advances batches automatically. `max_retries` is 0–3 per group per
invocation. After exhaustion, advisory mode with `finalize=True` delivers the
available text with findings. Strict mode or `finalize=False` raises
`translation-groups-failed`; reopen the same job to resume progress. Supply provider request timeouts and rate
limits in the callback. The adapter cannot cancel a provider that blocks forever.
`finalize=False` stops after translation so model timing can be evaluated without
rendering PDFs. The original serial `translate_with` interface remains available.

Native worker timing in `job.json` records group issue/accept timestamps and
successful validation duration. The interval includes queueing and client work;
overlapping group intervals must not be summed as wall time. Python callback runs
add `translation-runs/*.json` with each attempt's provider duration and total
translation wall time, excluding mechanical generation. A callback may use
cached text: its duration alone does not prove model generation occurred.

## Legacy whole-batch submission

Submit exactly this envelope; translation values are strings, not entry objects:

```json
{
  "api_version": 1,
  "batch_id": "<issued batch_id>",
  "translations": {
    "<issued entry_id>": "Target text with original typed markers preserved."
  }
}
```

The API verifies the submission envelope before saving any entry. Missing
or additional IDs, changed envelopes, blank text and malformed Unicode are
protocol errors. Missing/duplicated/reordered markers, changed paragraph counts,
unprotected math and long untranslated passages are advisory findings by default
and submission errors in strict mode. These are structural/completeness
checks; they do not prove semantic translation accuracy.

An identical repeated submission returns `accepted: true, replayed: true`.
A conflicting repeated submission fails without replacing previously accepted
text. Submit a corrected rejected batch using its original batch ID.

## Revising accepted translations

Use `revise` after review to correct committed target text without rebuilding
the source extraction or changing layout objects:

```json
{
  "translations": {"P001-T0000": "Corrected target text with every original typed marker preserved."},
  "reason": "Corrected word order identified during independent review."
}
```

The Python equivalent is `job.revise_translations(translations, reason)`.
Only IDs already committed in the frozen catalog may be revised. Finish any
outstanding batch first; revisions are unavailable while finalization is in
progress. The usual source hashes and writer lock are checked. Revisions must
pass the existing structural, paragraph and content checks even for an advisory
job; the job's saved delivery policy does not change. Submit target strings and
a nonempty reason only, never source text, formulas, coordinates or font settings.

A successful change atomically records the old and new text, reason, timestamp,
and text fingerprints in `job.json` under `translation_revisions`. The response
includes `revised`, `revised_entries`, and `revision_count`. Repeating identical
text is a no-op. Original batch and group receipts remain valid historical
receipts: replaying an original submission never overwrites a later revision.

The existing PDF and attempt files remain intact. The job returns to
`awaiting-translation`; when all entries are present its next action is
`finalize`, and the previous result has `up_to_date: false`. Finalization creates
a new immutable snapshot and consumes the same saved mechanical attempt budget.
If that budget is exhausted, `attempt-limit` preserves both the revised text and
the earlier PDF; it does not silently publish an outdated result as current.
Corrected text findings are cleared only for the revalidated IDs; source
extraction defects and unrelated findings remain recorded.

### Page-level revision and reuse

Normal `finalize` after a text revision automatically attempts incremental layout:

```sh
scripts/bilingual_pdf revise --job-dir work/paper --input corrections.json
scripts/bilingual_pdf finalize --job-dir work/paper
```

It compares page models and catalog entries with the latest compatible completed
attempt. Only changed pages run through the composer. Unchanged native PDF pages
are copied into the same output order; source-page numbers need not be contiguous.
Links and outlines are rebuilt for the complete document. Expensive raster/text
checks run on changed pages while previous page findings and summaries remain in
the new reports. Global mapping, manifest, outline and link checks still run.
An inherited warning never becomes a clean result just because its page was reused.

`result.incremental_layout` records `mode`, `rendered_source_pages`,
`reused_source_pages`, `checked_source_pages`, `diagnostics_reused`, and diagnostic
scopes. Full runs include a `reason`; incremental runs identify the base attempt.
The attempt's `incremental-plan.json` is hash-bound to its closed session and
lists the baseline artifacts. Previous attempts remain immutable. A revised
candidate can itself serve as the next verified baseline.

Reuse verifies source, model, catalog, PDF and diagnostic hashes, runtime and
font fingerprints, output policy, and a one-output-page-per-source-page map.
The first run, legacy artifacts without cache provenance, engine/font or policy
changes, unavailable cache, or changes to every page use full processing. If
only cached diagnostic coverage is unavailable, pages may still be reused but
the document receives a full audit and preflight. A failed changed-page renderer
uses page-local target recovery; a failed assembly falls back to full composition.

For an intentional complete rerun, use `finalize --full-rebuild` or
`job.finalize(incremental=False)`. `replay` also always performs full work.
Incremental attempts retain the existing attempt budget and locking rules.
No command requires editing `job.json`, frozen input models or prior reports.

The cache uses the immutable mechanical attempt, not an editable published copy
or a PDF under `repairs/`. Host repairs are tracked separately: inspect the repair
manifest and rebase those edits onto revised mechanical output before delivery.
Visual inspection may reuse prior coverage only for unchanged pages previously
verified by the host. New or changed pages always require inspection; API cache
reuse does not assert that a human or model has visually reviewed them.

## Persistence and recovery

### Handling rejected text

In strict mode, `translation-invalid` retains legacy `findings` strings and returns all
detected per-entry `issues`, with `entry_id`, `source_page`, `category`,
`retry_action`, and `message`. One rejected submission does not erase accepted
sibling groups. The rejected group remains atomic; keep its response file and
correct only the reported entries before submitting the complete group again.

In advisory mode these findings are saved in `job.json` as `quality_issues`;
the text is accepted and translation advances. They appear in the final Markdown
checklist. A warning does not trigger another translation request. Do not make
PDF delivery conditional on fixing the warning.

- `correct-translation`: repair the reported target text or marker/paragraph
  mismatch. A copied prose paragraph still requires translation, even if other
  entries in that group are correctly preserved names or code.
- `repair-extraction`: unprotected math already occurs in the source template.
  Do not delete it, invent MATH IDs, or keep sending the same translation to a
  model. Preserve the response and report the affected source page and entry.
- A suspected preservation conflict needs source evidence. The engine recognizes
  front-matter name lists before an Abstract/Summary boundary, syntactically
  recognized code in a monospaced source font, standalone email addresses,
  recorded table headers, and ACM
  reference-format citations. These source literals can pass completeness checks
  in old frozen jobs; new extraction keeps their native source objects out of the
  translation catalog. This is not an exemption for arbitrary English passages,
  monospaced instructions, or unmarked mathematics.

After a verified validator fix, collect the existing response files in the same
job before generating more text. This preserves IDs, receipts, glossary, and
accepted translations. A changed extraction rule requires a separate revision
job: retain the original job and only reuse text whose source and structural
markers match the revised entries. Never edit frozen files or blindly copy IDs.
During ordinary translation, diagnose engine defects and continue independent
documents; engine development and regression work are separate from translating
text. A retry limit is not evidence that diagnosis or saved-text recovery is
forbidden.

An incomplete catalog cannot be called a complete translation. Advisory
`finalize` snapshots saved text, including staged groups, and lists every missing
entry. Missing entries preserve only their own source region while saved neighbouring
targets are still drawn. Geometry errors generate source-anchored review plans;
postflight findings annotate the candidate without replacing translated pages.
Healthy pages use normal geometry. Exact extraction failures and OCR needs
remain explicit; chart numbers and formula fragments are never used as an
unstructured text substitute. Saved target prose stays recoverable in the job.
The parallel callback adapter delivers a partial artifact after provider retries
fail when `finalize=True`; `finalize=False` raises the failure to its caller.
Strict mode keeps
the earlier blocking behavior.

### Saved state

- `input/source.pdf`: original PDF snapshot; source hashes are checked on use.
- `job.json`: authoritative progress, receipts, active batch and attempt journal.
- `preparations/`: frozen extraction model and catalog skeleton, with hashes.
- `attempts/`: isolated, numbered mechanical attempts and their output/reports.
- `translated.pdf`: published result, unless a separate output was specified.

Accepted submissions update one JSON record with atomic replacement and fsync.
Only one process may mutate a job at a time. Its POSIX lock is inherited by
mechanical child processes, so a terminated client cannot start a competing
attempt while its renderer is still running. A busy command returns `job-busy`;
`status` remains readable.

`finalize` verifies inputs, snapshots accepted text and runs composition. Calling
it again recovers the existing result rather than generating another PDF. If the
client died after the engine finished, the job verifies the saved report, source
model, catalog, session ID and PDF hash before publishing. A missing published
copy is restored from the verified attempt artifact.

`resume` returns pending translation progress, retries interrupted preparation,
or recovers/reruns an interrupted mechanical attempt. It never retranslates saved
entries. Each attempt uses a new closed session with exactly one engine run.
`replay` explicitly starts another mechanical attempt with the same frozen
source model and accepted text, useful after an engine update. Both operations
respect the job's attempt limit and retain earlier diagnostics. They do not
alter frozen inputs or shorten translations. After a mechanical command
returns, the skill's host agent performs the default
[post-layout intelligent repair](post-layout-repair.md) on abnormal pages using
separate candidates. The standalone API/CLI does not invoke that pass or track
its final artifact; consult the repair manifest and deliver its verified PDF
and sibling checklist explicitly. `result.output` remains the mechanical PDF.

Copying the entire job directory preserves internal paths; a custom external
output path remains external. If frozen inputs have changed, recovery stops with
`input-changed` rather than silently rebuilding them.

## Outcomes and limits

`certified-layout` means the engine's layout, audit and preflight checks passed.
`draft-with-findings` and `partial-layout` are deliverable PDFs with recorded
limitations. None of these labels certifies linguistic accuracy. Requested
independent QA is marked pending on either a certified result or a draft; it
cannot silently change the mechanical certification.

In strict mode, scanned pages or unresolved encoding risks produce `needs-ocr`
with page numbers. Advisory mode translates safely extracted pages and preserves only
unextractable pages in the delivered PDF, with their incomplete status recorded
in the sibling checklist. This core does not perform OCR:
source-only pages are listed and `translation_complete` is false, even when the
artifact's phase is `completed`.

After extraction, C0 control characters can be resolved without OCR only when
every affected glyph is fully covered by a protected native formula component,
the recorded font matches, and translatable source templates are clean. The
original encoding risk and component evidence remain in the source manifest.
Replacement characters, corrupt prose and scanned pages are not exempted.

Completeness validation also distinguishes a labelled name roster inside an
explicit author/contributor section from untranslated prose. Its label must be
translated, while every source name and its order must remain intact. Batch
validation retains the document's section context without exposing layout
decisions to the translating client.

The original `scripts/bilingual_pdf --readduo-stage translation_session` prepare/validate/finalize interface
and internal script names remain compatible. Its v1 sessions keep their original
one-attempt semantics; new durable jobs are a separate protocol, not an implicit
migration or overwrite of existing sessions.

## Page-local failure and partial delivery

Advisory preparation isolates exact-extraction and OCR failures by source page.
Available saved target text always appears in a translated PDF candidate, even
with unsafe markers, missing neighbouring entries, collisions or render errors.
Normal source-anchored planning is followed by permissive region planning and,
if necessary, a page-local emergency target renderer. Critical postflight
findings never substitute an English page for existing translated ink. All
findings survive in the checklist, and review candidates are never certified.
Only pages with no target text remain source-only. Native evidence stays in the
source panel; emergency prose uses explicit formula pointers rather than
inventing mathematical expressions.

A partial PDF does not end translation: `next-work` and submissions continue
from the outstanding batch. `result.up_to_date` compares current saved text
with the delivered snapshot; re-finalize after new text is accepted.
`all_entries_submitted` is distinct from `translation_complete`; source-only
pages or content findings prevent the latter. Retain frozen inputs and logs.

### Translation candidate availability

`result.review_pages` lists source pages retained as translated review candidates;
`result.requires_visual_review` is true when these need checking.
`result.source_fallback_pages` lists only pages without a target candidate.
These fields do not certify visual correctness. Render `result.output` and
inspect the real translated panel before deciding whether a checker finding is
visible. A source-only legacy result with saved targets can be rerun with
`replay`; never discard its accepted translations or frozen inputs.

### Clean PDF pages and mandatory visual review

All newly generated candidates and final PDFs omit system status banners,
draft labels, warning strips and extra footer height. Missing-target and
source-only status stays in the checklist and manifest, not on PDF pages.
`result.visual_review` defaults to `{required: true, status: pending,
performed_by: host}`; this is separate from optional `independent_qa`.
The skill host must render and inspect every requested output page, repair
visible defects, and inspect edited pages again before final delivery.
The independent CLI cannot claim that a model visually reviewed its output.
