For this native candidate, use the JSON interfaces in [native-cli.md](native-cli.md); source-only Python SDK examples below do not apply.

> Candidate-output precedence: quality failures never suppress translated PDF
> ink. Normal rules below describe the desired plan and acceptance checks. If
> they fail, emit a flagged source-anchored review candidate, continue other
> regions, and use page-local emergency target rendering after operational
> exceptions. Preserve native source evidence on the left. Critical postflight
> findings annotate the same candidate; do not replace it with the source page.
> Only genuinely unavailable target text can justify source-only content.

# Deterministic layout contract

Durable jobs default to advisory delivery: content/layout findings are included
in a sibling `.issues.md` checklist. The normal planner may reject unsafe
structure, but candidate recovery still draws saved target text for visual
review. Healthy pages keep the geometric pipeline. Strict mode is an explicit
opt-in for acceptance checks; generated candidates are retained under either
policy. Source identity and write failures remain operational errors.

The installable implementation is now in `bilingual_pdf/engine/`. The old
`scripts/*.py` paths are compatibility entry points. New clients use the durable
[job API](job-api.md); each mechanical attempt below is an internal closed
session, not the lifetime of the outer job. Production never reads SKILL.md.
Skill-driven translation follows a completed mechanical attempt with an
authorized [intelligent repair pass](post-layout-repair.md) for abnormal pages.
That pass writes and verifies separate PDF candidates; it does not change this
engine contract or the frozen attempt's provenance and certification.


## Contents

1. Canonical page model
2. Translation catalog generation and input
3. Composer output manifest
4. Geometry and typography rules
5. Validation rules

## 1. Canonical page model

Generate the page model once inside the closed preparation command and use it
for translation and composition. The translating model must not inspect or
invoke the page-model builder directly:

```bash
python scripts/page_model.py INPUT.pdf \
  --pages 1,3-5 --output work/page-model.json
```

The model separates immutable source objects from reflowable text:

```json
{
  "version": 2,
  "model": "source-object-page-model",
  "formula_policy": "source-pdf-opaque-formula-units",
  "furniture_policy": "native-object-exact-geometry",
  "navigation_policy": "rebuild-source-links-and-outline",
  "text_layout_policy": "source-anchor-reflow",
  "toc": [
    {
      "id": "TOC-0001",
      "level": 1,
      "title": "Introduction",
      "target_source_page": 1,
      "target_point": [54, 82]
    }
  ],
  "pages": [
    {
      "source_page": 1,
      "source_page_size": [595, 842],
      "links": [
        {
          "id": "P001-L0001",
          "source_bbox": [54, 140, 120, 152],
          "source_region_id": "P001-T0003",
          "type": "internal",
          "target_source_page": 3,
          "target_point": [54, 210]
        }
      ],
      "furniture": [
        {
          "id": "P001-D0001",
          "kind": "rule",
          "source_bbox": [54, 38, 541, 38],
          "fingerprint_bbox": [54, 37.5, 541, 38.5],
          "segments": [
            {"start": [54, 38], "end": [541, 38]}
          ],
          "asset_source": "native-pdf-path",
          "protected": true
        }
      ],
      "text_regions": [
        {
          "id": "P001-T0003",
          "source_bbox": [54, 82, 541, 126],
          "role": "body",
          "alignment": "justified",
          "anchor": "top",
          "source_font_size": 10,
          "source_leading": 12,
          "source_line_count": 2,
          "line_break_policy": "preserve-semantic-source-line-count",
          "formula_ids": ["P001-M001"],
          "link_ids": ["P001-L0001"],
          "translation_template": "...比例为 <MATH:P001-M001>，见 <LINK:P001-L0001>[3]</LINK:P001-L0001> ..."
        }
      ],
      "formulas": [
        {
          "id": "P001-M001",
          "source_bbox": [320, 94, 338, 103],
          "source_baseline": 102,
          "source_components": [],
          "drawing_ids": [],
          "asset_source": "source-pdf-glyph-vector",
          "protected": true
        }
      ]
    }
  ]
}
```

Do not edit object coordinates by hand. Rebuild the model when extraction rules
change.
Replace isolated UTF-16 surrogate code points with `U+FFFD` before hashing or
JSON serialization, and record the replacement count per page. This
normalization is deterministic input repair, not translation.

## 2. Translation catalog generation and input

The default catalog source is the active host model, limited to filling target
text for already-modeled regions. Create its skeleton and closed session
mechanically, then let the host model change only each entry's `text` field:

```bash
python scripts/translation_session.py prepare INPUT.pdf \
  --source-language en --target-language zh-CN --pages 1 \
  --session-dir work/session --output output/translated.pdf
```

```json
{
  "version": 1,
  "catalog_type": "host-model",
  "model_assistance": true,
  "model_assistance_scope": "translation-catalog-only",
  "translation_generator": "active-host-model",
  "source_language": "en",
  "target_language": "zh-CN",
  "entries": {
    "P001-T0001-S00": {
      "source_sha256": "<sha256-of-exact-translation-template>",
      "source": "Example report title",
      "text": "示例报告标题"
    }
  }
}
```

`catalog_type` may be `client-catalog` for durable jobs, `host-model` for
legacy sessions, or `human-approved`, `rule-based`, and `translation-memory`
for legacy model-free catalogs. A client catalog declares `translation_origin`
as model, human, or translation-memory, with matching assistance metadata.
All client catalogs require the same frozen closed-session provenance. A host-model catalog must declare
`model_assistance=true`, `model_assistance_scope=translation-catalog-only`, and
a nonempty `translation_generator` identifying the caller. The model may translate the source
template, preserve its typed markers, and fill `text`; it may not edit hashes,
source strings, geometry, formulas, layout, or preflight data. The three
non-model catalog types must declare `model_assistance=false` and
`model_assistance_scope=none`.

The session compares the completed catalog with its immutable skeleton and
rejects every change outside `entries.*.text`. Structural catalog validation
may repeat while the session is `awaiting-translation`. After validation, the
catalog is snapshotted read-only, the model scope closes, and exactly one
mechanical run is authorized. The model scope remains closed throughout that
run. Layout, audit, and preflight findings are recorded without model repair
inside that run and do not suppress a successfully written PDF; they determine
mechanical certification only. The host may then inspect and repair that PDF
under the separate post-layout workflow.

Inside `translation_session.py finalize`, `compile_translation_catalog.py`
emits the only composition-authorized `translations.json` form. Direct
host-model compilation is rejected:

```json
{
  "translation_contract": {
    "source_language": "en",
    "target_language": "zh-CN",
    "pages": "1",
    "output_mode": "bilingual",
    "figure_policy": "preserve",
    "independent_qa": false,
    "production_mode": "mechanical",
    "translation_method": "deterministic-catalog",
    "model_assistance": true,
    "model_assistance_scope": "translation-catalog-only",
    "translation_generator": "active-host-model",
    "closed_session_id": "<32-hex-session-id>",
    "composition_authorized": true,
    "model_write_scope_closed": true,
    "mechanical_attempts": 1,
    "compiler_version": 3,
    "translation_catalog_type": "host-model",
    "translation_catalog_sha256": "<catalog-sha256>",
    "page_model_sha256": "<page-model-sha256>"
  },
  "translations": {
    "P001-T0001-S00": {
      "text": "示例报告标题"
    },
    "P001-T0003": {
      "text": "……混合比例为 <MATH:P001-M001>，见 <LINK:P001-L0001>[3]</LINK:P001-L0001>。……"
    },
    "P001-F0001": {
      "action": "preserve"
    }
  }
}
```

Rules:

- Require catalog and page-model hashes to match the exact input files.
- Reject unsupported origins and any model-assisted catalog whose assistance
  scope is not exactly `translation-catalog-only`.
- Reject missing or extra region IDs and stale source fingerprints.
- Use `text` for `translate`; `action` defaults to `translate`.
- Use `{"action": "preserve"}` only for source content intentionally retained.
- Mark the complete bibliography section, including its heading, with
  `role=bibliography`, `action=preserve`, and
  `preservation_reason=bibliography-permanent-rule` until the next top-level
  section.
- Include every model region exactly once.
- Preserve every expected `<MATH:id>` exactly once. The composer rejects missing
  placeholders before drawing.
- Preserve every paired `<LINK:id>...</LINK:id>` marker exactly once. Translate
  its visible contents when appropriate; the marker itself is never rendered.
- If source extraction cannot identify a trustworthy visible anchor, declare a
  source-rectangle fallback instead of inventing catalog text. Shift that
  rectangle with its owning region and validate its destination, but do not
  require visible link colour where no target glyph anchor exists.
- Do not include target coordinates, font sizes, or line breaks. The composer
  derives those from the page model, including source-derived semantic title
  line counts.

If a page-model revision changes region or formula IDs, migrate a frozen
translation memory with `migrate_translation_catalog.py` before compilation.
Migration must remain deterministic and model-free: map formulas by page,
geometry, baseline, and source-object structure; replay source clauses and
protected objects in the exact order declared by the region's
`translation_template`; convert newly protected formula literals into the
current `<MATH:id>` markers; and verify that exact ordered marker sequence. A
matching unordered set or the formula inventory's registration order is
insufficient. Fail on every
missing, extra, duplicated, reordered, or geometrically ambiguous formula
object rather than reusing an old ID by position or repairing target text.

## 3. Composer output manifest

`compose_pdf.py` writes `layout-manifest.json`:

```json
{
  "version": 2,
  "contract": {
    "output_mode": "bilingual",
    "target_language": "zh-CN",
    "figure_policy": "preserve",
    "independent_qa": false,
    "production_mode": "mechanical",
    "translation_method": "deterministic-catalog",
    "model_assistance": true,
    "model_assistance_scope": "translation-catalog-only",
    "translation_generator": "active-host-model",
    "closed_session_id": "<32-hex-session-id>",
    "composition_authorized": true,
    "model_write_scope_closed": true,
    "mechanical_attempts": 1,
    "compiler_version": 3,
    "translation_catalog_type": "host-model",
    "translation_catalog_sha256": "<catalog-sha256>",
    "page_model_sha256": "<page-model-sha256>",
    "formula_policy": "source-pdf-opaque-formula-units",
    "furniture_policy": "native-object-exact-geometry",
    "source_geometry_policy": "source-geometry-exact",
    "navigation_policy": {
      "links": "source-and-translation-panels",
      "internal_target_panel": "same-as-link-panel",
      "toc_target_panel": "translation",
      "unselected_internal_targets": "record-unresolved"
    },
    "text_layout_policy": "source-anchor-reflow",
    "font_size_policy": {
      "target_ratio": 1.0,
      "tolerance": 0.01,
      "allow_auto_shrink": false
    },
    "font_family_policy": {
      "cjk": "Songti SC",
      "latin": "Times New Roman",
      "mixed_script_segmentation": "unicode-script-runs",
      "protected_source_objects_exempt": true
    },
    "line_spacing_policy": {
      "preferred_ratio": 1.2,
      "minimum_ratio": 1.0,
      "minimum_em": 1.05,
      "target_normal_em": 1.12,
      "tolerance": 0.02,
      "compress_only_on_capacity_failure": true,
      "inline_formula_changes_advance": true,
      "formula_expansion": "source-leading-once-plus-pairwise-visible-ink-clearance",
      "paragraph_spacing": "source-excess-scaled-with-0.35em-optical-minimum",
      "fixed_text_baseline": "exact-source-baseline"
    }
  },
  "toc": [
    {
      "id": "TOC-0001",
      "level": 1,
      "title": "Introduction",
      "output_page": 1,
      "output_target_point": [649, 82],
      "status": "inserted"
    }
  ],
  "unresolved_navigation": [],
  "pages": [
    {
      "source_page": 1,
      "output_page": 1,
      "translation_panel": [595, 0, 1190, 842],
      "figure_policy_decisions": [
        {
          "id": "compound-1",
          "policy": "auto",
          "classification": "sparse",
          "region_count": 8,
          "characters": 96,
          "text_area_ratio": 0.08,
          "action": "preserve",
          "text_layer_owner": "source",
          "source_text_removal_required": false,
          "thresholds": {
            "maximum_regions": 20,
            "maximum_characters": 300,
            "maximum_text_area_ratio": 0.18
          }
        }
      ],
      "links": [
        {
          "id": "P001-L0001",
          "panel": "translation",
          "type": "internal",
          "output_bbox": [649, 140, 715, 152],
          "output_target_page": 3,
          "output_target_point": [649, 210],
          "status": "inserted"
        }
      ],
      "regions": [
        {
          "id": "P001-T0003",
          "role": "body",
          "source_bbox": [54, 82, 541, 126],
          "bbox": [649, 82, 1136, 126],
          "vertical_shift": 0,
          "source_font_size": 10,
          "font_size": 10,
          "size_ratio": 1.0,
          "source_leading": 12,
          "target_leading": 14.4,
          "leading_ratio": 1.2,
          "formula_expanded_leading": false,
          "source_line_count": 2,
          "target_line_count": 2,
          "line_break_policy": "preserve-semantic-source-line-count",
          "contains_formula_ids": ["P001-M001"],
          "flow_lane": "page",
          "overflow": false
        },
        {
          "id": "P001-M001",
          "role": "formula",
          "protected": true,
          "source_page": 1,
          "source_bbox": [320, 94, 338, 103],
          "bbox": [915, 94, 933, 103],
          "asset_source": "source-pdf-glyph-vector",
          "source_fingerprint": "...",
          "target_fingerprint": "..."
        }
      ],
      "source_skeleton_expected_count": 0,
      "skeleton": []
    }
  ]
}
```

The composer, not the calling agent, calculates target boxes, shifts,
fingerprints, capacity, and output-panel offsets.

If the geometry composer exits by signal, returns nonzero, or omits its output,
`recover_composition.py` retries each page in a separate process using the same
frozen inputs. Failed pages with saved targets use the independent emergency
target renderer; the full prose is drawn and unresolved formulas point to source
evidence. Healthy pages keep their translated geometry. Logs survive in
`page-recovery/`; internal links and outlines use the resulting page map.
Critical audit/preflight findings discovered after drawing annotate the retained
candidate and require visual review; they do not replace its translated ink.
Only pages without available target text retain the original with incomplete status in the checklist.

## 4. Geometry and typography rules

### Compact bilingual panels

Bilingual pages preserve source scale and vertical coordinates. Estimate the
visible content margins, crop half of each facing margin, and use the resulting
translation origin throughout geometry, annotations, bookmarks and audit. The
combined inner whitespace is exactly half its former width. Wide figures limit
margin cropping; duplicate marginal stamps remain on the outside source panel.
The manifest records the native clips and measured gap. A full-source-width
logical translation panel can overlap the cropped source margin; the visible
panel divider is recorded separately.

Numbered headings retain their source baseline; body expansion cannot move them.
Normal paragraph leading defaults to the source value (at least one em for
readability), with only actual inline-math clearance expanding individual gaps.
Standalone equations keep their source location/centering, including equation
numbers, and header rules remain native source objects. These are required in
advisory mode as well as strict mode.

### Immutable source objects

- Inventory only visually effective PDF paths. A fill or stroke whose effective
  opacity is zero is not furniture, never becomes a collision blocker, and is
  not redrawn as opaque content. If a visible source path crosses the page
  boundary, retain its exact source geometry but validate the target using the
  same page-clipped visible portion. Fully off-page paths are filtered before
  serializing primitives, including in strict mode; legacy inventories receive
  the same visibility filter during preflight. Boundary-touching strokes count
  as visible. Paths with more than 4096 primitives keep native provenance,
  bbox, primitive count and operation types without duplicating coordinates in
  JSON. Their complete geometry stays in the source PDF/page base; do not
  reconstruct them from the compact inventory.
- Map furniture, rules, logos, figures, images, tables, and algorithms by exact
  source geometry plus panel offset. Treat formulas as source-derived opaque
  units: standalone paragraphs stay fixed, while inline units may relocate.
- Preserve zero-height and zero-width rule bboxes. Use their stroke-aware
  fingerprint boxes only for raster comparison.
- Preserve formula width, height, glyphs, curves, baseline, internal spacing,
  equation number, and line breaks.
- Expand every semantic formula envelope to the union of all declared source
  components, and absorb compact arrow/script blocks on the same displayed
  equation row before isolating the vector object.
- Model raised numeric footnote references and footnote-entry labels as
  protected inline source objects. Store both the compact glyph bbox and the
  ordinary visual-line baseline; the target must retain the same negative
  bottom-to-baseline offset.
- Treat symbol-font glyphs and small leading footnote images as inline source
  objects rather than translatable control characters or fixed page furniture.
  Remove a moved image once from the translated-panel base, then place its
  exact-size source clip once in source order.
- Treat a visually effective math-font glyph whose broken `ToUnicode` map
  exposes it as whitespace as a protected glyph, not as an empty character.
  Resolve it by the declared component font, source box, baseline, and native
  SVG path origin. For Unicode combining marks only, tolerate a bounded
  two-dimensional difference between the PDF text origin and SVG drawing
  origin inside the same formula envelope; ordinary glyphs still require an
  exact origin match.
- Treat a semantic formula region as the protected object boundary, including
  upright function names such as `L2Norm`, `Diag`, or `ShortConv`; glyph-level
  math classification is not a license to drop the ordinary-font pieces.
- After the final envelope is closed, extract and store its source-visible text
  from the native PDF clip. This field is an integrity aid for proving exact
  adjacent target echoes such as a duplicated `Diag(`; it must never be used to
  retype, translate, or reconstruct the formula.
- Before catalog handoff, if a region declares a formula ID but its marker is
  absent, replace only an exact whitespace-flexible match of that formula's
  native source-visible text with the marker. Record the recovery and fail the
  handoff if no exact match exists; never ask the translating model to repair it.
- Group a fragmented numbered display equation into one protected visual object;
  do not independently reflow its font runs. Exclude prose-heavy proposition,
  theorem, lemma, corollary, and explanatory prefixes even if the prefix ends
  with a detected mathematical symbol; those prefixes remain text regions.
- Copy one immutable source-page base into each translated panel, redact only
  translated text, and keep native vector paths, images, charts, and
  source-anchored formulas on that base. Never redraw or reinsert an object
  already present there.
- Do not translate pure formula paragraphs. During mixed-paragraph translation,
  replace every inline formula with a typed marker and restore the same formula
  object afterward. Typeset it as one indivisible native-vector unit; relocate
  all source glyphs, scripts, curves, and forms with one transform while
  preserving size and internal relative geometry. A raster crop, screenshot,
  Unicode reconstruction, or formula retyping is never an acceptable substitute.
- Give each figure exactly one text-layer owner. `preserve` and sparse `auto`
  decisions keep the source figure and all internal labels intact and forbid
  translated overlays. Explicit `translate` and dense `auto` decisions must
  remove the complete source label layer before any target label is rendered;
  if a source label remains, reject the page.
- Cluster nearby small PDF paths before figure classification. Treat text and
  formulas inside the resulting vector-figure envelope as figure-owned,
  regardless of path colour: keep their glyphs and surrounding cells on the
  immutable source base and forbid any target text overlay in that envelope.
- Compare moved objects with sub-pixel alignment, symmetric ink-shape coverage,
  and an independent ink-mass ratio. For zero-height rules, verify native path
  coordinates, stroke width, and multiplicity instead of raw antialias pixels.

### Source-anchored text reflow

- Infer independent flow lanes from source x-bands and preserve each lane's
  source x-bounds. Repeated broad body rows are decisive single-column
  evidence; never let short equation fragments create false columns.
- Once a stable two-column split is established, neither formula-fragment
  attachment nor overlapping-region merging may cross the column gutter. A
  formula in the opposite column is not an inline bridge even when its y-range
  overlaps the prose row.
- Keep header, footer, page-number, and page-furniture slots exact.
- Classify bottom text by repetition and content before fixing it: running
  matter stays anchored. A page-local note beneath a source-authored bottom
  rule belongs to a fixed footnote zone; its top anchor stays fixed and body
  flow must end above the stroke-aware rule boundary.
- Preserve the first measured source visual baseline for fixed header, footer,
  page-number, and fixed-zone text. Never substitute `bbox top + target size`.
- Detect footnote labels by whole-page row geometry, not only raw block
  membership. If a label and its body were extracted into different blocks,
  attach the label to the nearest rightward text on the same visual row.
- Keep each leading footnote sequence in source order (`marker`, optional icon,
  linked note text) and make the sequence a legal line-break group.
- Keep the source top and full source box when translated text fits.
- Keep table bodies and pseudocode algorithms source-identical as fixed
  structured blocks. Table titles/captions are separate translatable regions;
  their boxes must not enlarge the immutable table envelope. Headers, cells,
  rules, values and internal formulas stay on the source base.
- Detect a complete table envelope from a table caption plus a geometrically
  compatible cluster of horizontal rules. Freeze every text region whose
  centre lies inside that envelope; a partially detected row is not permission
  to redact or translate the remaining cells.
- When a document title is followed by names, affiliations, email addresses,
  or contribution notes before the first prose-section heading, preserve that
  complete metadata band at source geometry. These small independent PDF boxes
  must never enter ordinary text flow. An `ABSTRACT` or `SUMMARY` token at the
  start of a merged heading-plus-body block is a valid lower boundary.
- Do not freeze `General Terms`, `Keywords`, `Index Terms`, subject descriptors,
  or classification rows merely because extraction classified their values as
  identifiers; they remain semantic target-language content.
- Split one extracted heading block whenever two or more source visual rows
  begin with distinct hierarchical numbers. Keep wrapped continuation rows
  with their nearest numbered heading and preserve the hierarchy order.
- Treat repeated source bullet starts as explicit paragraph boundaries before
  catalog creation, even when the extractor returned one paragraph block.
- When it does not fit, retain font size, expand downward, preserve the original
  gap to the next peer, and shift downstream peers in the same lane. A
  full-width region shifts all downstream lanes.
- When page-bottom capacity fails, first redistribute only measured whitespace
  above the page flow with one common upward shift. Bound that shift by the
  nearest hard upper anchor, record it, and reject any new collision. Only then
  may the solver compress leading.
- When the final flowing block before a fixed page number, footer, table header,
  rule, or formula still collides, reclaim only measured local whitespace above
  that block. Preserve a deterministic minimum gap to the preceding visible
  ink and reject the nudge if it cannot clear every protected object.
- Preserve the source-authored gap across adjacent regions when the preceding
  region contains a flowing formula whose target ink descends farther than its
  source envelope; shift the following region and its downstream flow together.
- Preserve the source-authored gap between an image or other protected object
  and an immediately following caption when the target font's visible ascent
  extends above its layout box; shift the caption and downstream flow together
  by the measured ascent difference rather than accepting overlap or shrinking
  the text.
- Preserve intentional source overlap. Record every newly introduced overlap as
  a layout finding; continue rendering the deterministic draft and withhold
  certification.
- Source-preserved identifiers, tables, algorithms, and standalone formulas do
  not move with text flow. Inline formula units move only as part of their
  translated paragraph's typesetting sequence.
- Use source-PDF text spans, not merged-region summaries, as the authoritative
  text-removal geometry. Exclude figure-owned labels, expand formula objects to
  all owned glyph components, and split wrap-around prose into side-of-figure
  and below-figure flow regions before target layout.
- Record every vertical shift.
- Record unresolved page overflow and render the complete deterministic plan as
  a draft. Never silently label an overflowing or clipped artifact certified.
- For multi-line semantic titles and headings, preserve at least the source line
  count and use source visual-line boxes when the target lines fit. Derive clear
  punctuation boundaries from the source rather than requiring translated hard
  returns.
- Give compact centred titles, attributions, and front-matter rows one common
  visual axis. Individual extracted row bboxes may constrain width but must not
  redefine that axis. Reserve the source-derived prefix width of an inline logo
  or icon so the combined object-plus-text row, not the text alone, is centred.
- Never infer a compact centred row from ordinary body, bibliography, note,
  heading, header, footer, or page-number prose merely because a short final
  source line happens to be visually centred.
- Preserve a formula-dominant multi-line expression as one source object when
  its only visible words are mathematical identifiers or condition labels;
  detached punctuation belonging to that expression is also source-preserved.
- Promote a short relation/operator-dominant display row and its same-column
  fragments to fixed source objects. Never extend this grouping across a
  stable column gutter or into a heading, URL, email address, table, algorithm,
  front matter, bibliography, or long prose region.
- Keep every display-group formula as a collision blocker even when a preserved
  semantic region owns it. Ownership prevents duplication; it does not permit
  preceding translated prose to flow through the fixed display equation.
- Preserve logical paragraph boundaries and their source-derived extra spacing
  independently from ordinary line leading. Use the scaled source excess or a
  `0.35 em` optical minimum, whichever is larger.

### Typography

- Apply `S_target = 1.00 × S_source` with tolerance `0.01`.
- Disable auto-shrink.
- Use Songti SC for translated Chinese runs and Times New Roman for translated
  Latin/digit runs.
- Use bold only for semantic headings or source emphasis.
- Use the measured source baseline gap as the minimum. For ordinary tight
  lines, raise it only to a `1.12 em` CJK optical floor, capped at `1.2 ×` the
  source gap. Formula-expanded source gaps remain at `1.0 ×` and are never
  multiplied a second time. If the complete page cannot fit, compress only the
  added optical allowance; do not compress font size or the source gap.
- Rebuild the source line profile from visible full-size glyph baselines after
  formula grouping. Ignore TeX control and delimiter artifacts, apply the
  selected `1.0–1.2 ×` source-baseline ratio as normal leading, then expand only
  an adjacent line pair whose visible text/formula ink would otherwise collide.
- Use real justification; never simulate it with inserted spaces.
- Limit added justification space to `0.25 em` per eligible gap. If a legal
  nonfinal line exceeds that limit, record and use a left-aligned fallback.
- Never justify a paragraph-final line, including paragraph ends inside one
  merged extraction region.
- Preserve mixed source weight as inline runs. A boundary-aligned leading bold
  run maps by target sentence/clause ordinal; dominant-span classification must
  never bold a complete mixed-weight region.
- Treat adjacent components of one compact formula expression as a keep-together
  group. Break around the group and retain source-object order; never reorder
  overlapping extractor fragments by x-coordinate alone.
- Bind a plain single-letter formula base to an immediately following protected
  script object when that object's first source glyph is on a smaller raised or
  lowered baseline; never leave the base at the end of the previous line.
- Save and reopen the complete PDF before any font optimization. Run font
  subsetting in an isolated process against a separate copy, atomically adopt
  it only after page-count validation, and retain the unoptimized PDF when the
  optimizer crashes, times out, or emits invalid output.

### Navigation objects

- Inventory annotations and outline entries before composition; never expect
  `show_pdf_page` to copy them.
- Wrap each discoverable translated anchor in paired typed link markers and map
  the final annotation rectangle to the marker's actual laid-out glyph boxes.
  Use the shifted source rectangle only as an explicit fallback when the source
  anchor text cannot be identified.
- For URI annotations whose extracted text accidentally spans neighboring
  lines, prefer the annotation's canonical URI as the anchor when that exact
  string exists in the region template.
- For internal references split by extraction, mechanically try the exact
  anchor, citation token, range suffix without a duplicated dash, canonical
  section/theorem identifier without spill characters, and an exact formula
  marker whose source-visible text equals the anchor. Record the selected
  variant and fail catalog handoff if any declared link remains unmarked.
- Record the dominant source span color of each visible link and apply that
  exact RGB color to its translated anchor glyphs.
- Preserve URI, launch/file, remote-document, and resolvable internal links.
- In bilingual output, create one clickable rectangle on each panel. Source-side
  internal links target source coordinates; translation-side links target the
  corresponding reflowed translation coordinates.
- Preserve outline levels and titles. Point outline entries at the translation
  panel unless the translation contract explicitly requests another target.
- When only selected pages are emitted, do not create broken links to absent
  pages. Record those links and outline entries in `unresolved_navigation` with
  `target-page-not-selected` or `toc-target-page-not-selected`.

## 5. Validation rules

Preflight must report failure when:

- mechanical provenance is absent, uses an unsupported catalog type, grants
  model assistance beyond `translation-catalog-only`, or contains
  malformed/stale hashes;
- a host-model payload lacks a valid closed-session ID, authorizes more than one
  mechanical attempt, leaves the model write scope open, or reaches composition
  outside `translation_session.py finalize`;
- required contract fields are missing;
- a selected page or translation panel is missing;
- the mapped source-skeleton count differs from the page's declared expected
  count; an explicitly declared count of zero is a valid skeleton-free page;
- a rule, logo, image, or formula object is missing, moved, resized, or covered;
- source/target formula or rule fingerprints are stale or materially different;
- deterministic figure-policy decisions are absent, conflict with the contract,
  or use stale classification thresholds;
- a protected superscript marker loses its declared source/target baseline or
  changes its raised baseline offset;
- a formula placeholder is missing or retyped as ordinary Unicode/ASCII;
- formula placeholders occur in a different order from the current source
  model, or a migrated catalog resolved a formula solely by a stale ID;
- target prose immediately adjacent to a formula duplicates an operator,
  delimiter, or atom visibly owned by the final formula envelope without the
  source template owning the same boundary fragment;
- a fixed header/footer slot moves or overflows;
- a text region moves upward without a bounded upward-reflow declaration,
  exceeds its declared hard-anchor limit, changes column x-bounds, or reports
  an incorrect vertical shift;
- translated text changes point size, uses a forbidden font face, clips,
  crosses the gutter, or introduces a new collision;
- a translated region introduces visible-ink overlap with another translated
  region or any structurally preserved source region beyond the overlap already
  present in the source;
- author/front-matter metadata, a rule-bounded table region, an algorithm
  region, or a display-equation row differs textually or geometrically from its
  exact source clip;
- a translated Latin/digit run outside a protected source object does not use
  Times New Roman, a bibliography region differs from the source, or a figure
  contains both source-owned and target-owned text layers;
- a justified region or heading hierarchy violates its contract.
- a multi-line semantic title or heading collapses below its source line count;
- semantic rows do not share their declared alignment axis, paragraph counts
  change, paragraph gaps fall below the optical minimum, or a sparse-
  justification fallback is used without being recorded;
- normal target leading lies outside the adaptive `1.0–1.2 ×` range, or a
  formula-expanded adjacent line pair still overlaps;
- a hyperlink is absent, has the wrong rectangle, URI/file value, output page,
  panel, target coordinate, or visible source-derived text color;
- an outline entry changes level, title, order, page, or destination;
- a navigation object is silently dropped or has an unsupported unresolved
  status.

Treat preflight as verification of the generated page model and composer
output, not as permission to create or suppress the artifact. A nonzero
preflight or audit result makes the delivered PDF `draft-with-findings`; the
mechanical pipeline still copies the draft to the requested output path. No
model may inspect, choose, or repair layout during that run. After it returns,
the host may repair affected PDF regions/pages in a separate candidate and
verify the result. General engine-rule changes belong to skill development
with regression coverage; they are not necessary for a bounded PDF repair.
Source-page fallback must be disclosed in the checklist and manifest, and cannot
be described as a complete translation. Do not add system warnings or status
strips to the PDF. Host visual inspection of every requested page is required
by default; independent QA is a separate opt-in.

Font-family mismatch is a major style finding, not evidence that an entire
page is unsafe. Actual source/target text-layer overlaps remain critical,
including short prefixes that a whole-block untranslated-text check misses.
Numbered display equations are identified at source-line/glyph level even
inside mixed prose blocks. Their full operators, limits and numbering remain
source-owned; prose removal shields every retained formula glyph cell.
# Bounded repairs of existing bilingual PDFs

`scripts/bilingual_pdf repair region --input repair.json` supports
equal, unscaled source-left/target-right panels with one-to-one page mapping.
The caller selects source and target repair bounds after inspecting actual
ink, including detached accents, tall delimiters and limits. Font metric boxes
alone can include adjacent prose or omit visible extension glyphs. Copy native
PDF artwork rather than reconstructing mathematics from extracted Unicode.

If explanatory prose shares the damaged region, supply a complete measured
paragraph plan using native inline formula assets. Keep the source clip clear
of that prose. The helper writes a separate candidate and returns hashes plus verification
scope. Its default `verification_policy="readable"` checks the edited page at
144 dpi with small raster differences tolerated; it does not rerender unrelated
pages. Explicit `verification_policy="strict"` verifies the restored clip at
288 dpi and all pages outside the declared repair region at 144 dpi. A failed check
does not authorize publication of that candidate. Independently render the
repaired region to inspect antialiasing, accents, scripts and text clearance.

For a damaged explanatory paragraph whose inline formula assets are intact,
omit `source_box` and supply the complete paragraph plan. This verifies the
outside-region invariant; there is no whole-clip identity claim. Check the
native inline formulas against the source separately. Adjacent extraction
fragments of one continuous explanation may be laid out together, preserving
all source meaning and logical paragraph boundaries.


### Numbered list structure and hanging indentation

`list_structure.restore_numbered_list_items` recognizes sequential source-line
markers using native span positions, reassembles inline-formula fragments, and
emits a separate region for each complete item. Inline equation references do
not establish list boundaries. Cross-column content, unrelated unindented prose,
tables and display equations are not silently merged into lists.

Each `list_item` records the source marker, number, marker/body x coordinates,
hanging indent and the marker/label weight. The complete item is translated as
one unit with opaque math and link markers. Source emphasis after an unbold
number is still emphasis; only the label before the target colon becomes bold.
The layout engine places the number separately and wraps every body line in the
body column, widening the gap if a localized number requires it. Neither text
nor a formula may intrude to the left of the marker. Preserve ordinary source
leading and allow extra formula ink clearance without inventing paragraph gaps.

Visual acceptance checks item boundaries, both labels' weight, numbering and
continuation alignment in the actual output. Retain candidate output and its
diagnostics if any of these checks fail, then repair before final delivery.
