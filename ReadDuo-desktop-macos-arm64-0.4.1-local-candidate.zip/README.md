# ReadDuo — local native candidate

ReadDuo by Castle Zeng creates source-left / translation-right bilingual PDFs,
with resumable jobs, visual review and a separate issue checklist.

This is a **local evaluation candidate for macOS on Apple silicon**. It has
not been authorized for public redistribution: the current PDF dependency's
commercial license remains undecided. Do not upload this archive as a public
GitHub release or to an OpenAI directory.

The candidate bundles a compiled engine and its Python runtime. It does not
include ReadDuo's Python source, regression tests or compiler work files.
Skill instructions, JSON command protocols, metadata and third-party license
texts remain readable. Native compilation is not a guarantee against reverse
engineering.

The private output folder also contains a `ReadDuo Native Local` marketplace
catalog pointing at the unpacked candidate. Open that folder as a local project
and select that marketplace for installation, or inspect the unpacked package.
Run setup to check Poppler and required system
fonts. No system Python installation is needed for the native engine. Keep
PDFs, jobs, review images and outputs in a separate writable workspace.

The active host model supplies translations and visual review. ReadDuo's
engine performs extraction and PDF composition; host model and file handling
still applies. Scanned pages need OCR first. Table interiors, pseudocode,
references and diagram labels remain source-owned by default; captions are
translated. Complex layouts may need repair or retain disclosed findings.

Source development stays in the private development folder. A public download
repository can be prepared separately, but no source tree or local candidate
is uploaded while dependency licensing remains unresolved.
